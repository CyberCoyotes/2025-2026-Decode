// IDENTIFIERS_USED=clawAsServo,droneAsServo,gamepad1,gamepad2,leftDriveAsDcMotor,leftExtendAsDcMotor,leftLiftAsDcMotor,leftWristAsServo,rightDriveAsDcMotor,rightExtendAsDcMotor,rightLiftAsDcMotor,rightWristAsServo

var MaxPower, LeftPower, RightPower;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  leftDriveAsDcMotor.setDirection("REVERSE");
  rightExtendAsDcMotor.setDirection("REVERSE");
  rightLiftAsDcMotor.setDirection("REVERSE");
  leftWristAsServo.setPosition(1);
  rightWristAsServo.setPosition(0);
  droneAsServo.setPosition(1);
  leftLiftAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightLiftAsDcMotor, "BRAKE");
  clawAsServo.setPosition(1);
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    MaxPower = 0.75;
    while (linearOpMode.opModeIsActive()) {
      if (gamepad2.getDpadUp()) {
        leftExtendAsDcMotor.setDualPower(0.75, rightExtendAsDcMotor, 0.75);
      } else if (gamepad2.getDpadDown()) {
        leftExtendAsDcMotor.setDualPower(-0.75, rightExtendAsDcMotor, -0.75);
      } else {
        leftExtendAsDcMotor.setDualPower(0, rightExtendAsDcMotor, 0);
      }
      if (gamepad2.getA()) {
        clawAsServo.setPosition(0);
      } else if (gamepad2.getB()) {
        clawAsServo.setPosition(1);
      }
      if (gamepad1.getStart()) {
        droneAsServo.setPosition(0);
      }
      if (gamepad2.getRightBumper()) {
        leftLiftAsDcMotor.setDualPower(0.75, rightLiftAsDcMotor, 0.75);
      } else if (gamepad2.getLeftBumper()) {
        leftLiftAsDcMotor.setDualPower(-0.75, rightLiftAsDcMotor, -0.75);
      } else {
        leftLiftAsDcMotor.setDualPower(0, rightLiftAsDcMotor, 0);
      }
      if (gamepad1.getA()) {
        leftWristAsServo.setPosition(0.5);
        rightWristAsServo.setPosition(0.35);
      } else if (gamepad1.getB()) {
        leftWristAsServo.setPosition(1);
        rightWristAsServo.setPosition(0);
      }
      LeftPower = gamepad1.getLeftStickY() * MaxPower;
      RightPower = gamepad1.getRightStickY() * MaxPower;
      leftDriveAsDcMotor.setDualPower(LeftPower, rightDriveAsDcMotor, RightPower);
      telemetry.update();
    }
  }
}
