// IDENTIFIERS_USED=clawAsServo,gamepad1,leftDriveAsDcMotor,leftWristAsServo,rightDriveAsDcMotor,rightWristAsServo

var myTfodRecognitions, USE_WEBCAM, myTfodProcessor, myTfodRecognition, myVisionPortal, x, y;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  USE_WEBCAM = true;
  // Initialize TFOD before waitForStart.
  initTfod();
  rightDriveAsDcMotor.setDirection("REVERSE");
  leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
  clawAsServo.setPosition(0);
  leftWristAsServo.setPosition(1);
  rightWristAsServo.setPosition(0);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Touch Play to start OpMode');
  // Set the minimum confidence at which to keep recognitions.
  tensorFlowAccess.setMinResultConfidence(myTfodProcessor, 0.75);
  // Indicate that only the zoomed center area of each
  // image will be passed to the TensorFlow object
  // detector. For no zooming, set magnification to 1.0.
  tensorFlowAccess.setZoom(myTfodProcessor, 1.25);
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetryTfod();
      // Push telemetry to the Driver Station.
      telemetry.update();
      leftDriveAsDcMotor.setDualTargetPosition(800, rightDriveAsDcMotor, 800);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.5, rightDriveAsDcMotor, 0.5);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(2000);
      leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
      leftDriveAsDcMotor.setDualTargetPosition(350, rightDriveAsDcMotor, 0);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.25, rightDriveAsDcMotor, 0.25);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(1000);
      clawAsServo.setPosition(1);
      linearOpMode.sleep(1000);
      leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
      leftDriveAsDcMotor.setDualTargetPosition(-500, rightDriveAsDcMotor, -500);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.25, rightDriveAsDcMotor, 0.25);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(2000);
      leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
      leftDriveAsDcMotor.setDualTargetPosition(0, rightDriveAsDcMotor, 400);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.25, rightDriveAsDcMotor, 0.25);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(2000);
      leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
      leftDriveAsDcMotor.setDualTargetPosition(1900, rightDriveAsDcMotor, 1900);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.25, rightDriveAsDcMotor, 0.25);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(3000);
      leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
      leftDriveAsDcMotor.setDualTargetPosition(0, rightDriveAsDcMotor, 1187);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.25, rightDriveAsDcMotor, 0.25);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(4000);
      leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
      leftDriveAsDcMotor.setDualTargetPosition(3000, rightDriveAsDcMotor, 3000);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      leftDriveAsDcMotor.setDualPower(0.25, rightDriveAsDcMotor, 0.25);
      leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
      linearOpMode.sleep(25000);
      if (gamepad1.getDpadDown()) {
        // Temporarily stop the streaming session.
        visionPortalAccess.stopStreaming(myVisionPortal);
      } else if (gamepad1.getDpadUp()) {
        // Resume the streaming session if previously stopped.
        visionPortalAccess.resumeStreaming(myVisionPortal);
      }
    }
  }
}

/**
 * Initialize TensorFlow Object Detection.
 */
function initTfod() {
  myTfodProcessor = tensorFlowAccess.easyCreateWithDefaults();
  if (USE_WEBCAM) {
    myVisionPortal = visionPortalAccess.easyCreateWithDefaults_oneProcessor(navigationAccess.getWebcamName("Webcam 1"), myTfodProcessor);
  } else {
    myVisionPortal = visionPortalAccess.easyCreateWithDefaults_oneProcessor(navigationAccess.getBuiltinCameraDirection("BACK"), myTfodProcessor);
  }
}

/**
 * Display info (using telemetry) for a detected object
 */
function telemetryTfod() {
  // Get a list of recognitions from TFOD.
  myTfodRecognitions = JSON.parse(tensorFlowAccess.getRecognitions(myTfodProcessor));
  telemetryAddTextData('# Objects Detected', listLength(miscAccess, myTfodRecognitions));
  // Iterate through list and call a function to
  // display info for each recognized object.
  for (var myTfodRecognition_index in myTfodRecognitions) {
    myTfodRecognition = myTfodRecognitions[myTfodRecognition_index];
    telemetry.addLine('');
    // Display the label and confidence for the recognition.
    telemetryAddTextData('Image', [startBlockExecution("TfodRecognition.Label") ? endBlockExecution(myTfodRecognition.Label) : 0,' (',miscAccess.formatNumber((startBlockExecution("TfodRecognition.Confidence") ? endBlockExecution(myTfodRecognition.Confidence) : 0) * 100, 0),' % Conf.)'].join(''));
    x = ((startBlockExecution("TfodRecognition.Left") ? endBlockExecution(myTfodRecognition.Left) : 0) + (startBlockExecution("TfodRecognition.Right") ? endBlockExecution(myTfodRecognition.Right) : 0)) / 2;
    y = ((startBlockExecution("TfodRecognition.Top") ? endBlockExecution(myTfodRecognition.Top) : 0) + (startBlockExecution("TfodRecognition.Bottom") ? endBlockExecution(myTfodRecognition.Bottom) : 0)) / 2;
    // Display the position of the center of the detection boundary for the recognition
    telemetryAddTextData('- Position', [miscAccess.formatNumber(x, 0),', ',miscAccess.formatNumber(y, 0)].join(''));
    // Display the size of detection boundary for the recognition
    telemetryAddTextData('- Size', [miscAccess.formatNumber(startBlockExecution("TfodRecognition.Width") ? endBlockExecution(myTfodRecognition.Width) : 0, 0),' x ',miscAccess.formatNumber(startBlockExecution("TfodRecognition.Height") ? endBlockExecution(myTfodRecognition.Height) : 0, 0)].join(''));
  }
}
