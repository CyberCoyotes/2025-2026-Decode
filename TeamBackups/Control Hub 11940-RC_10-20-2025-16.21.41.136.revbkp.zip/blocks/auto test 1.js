// IDENTIFIERS_USED=clawAsServo,leftDriveAsDcMotor,leftLiftAsDcMotor,leftWristAsServo,rightDriveAsDcMotor,rightExtendAsDcMotor,rightLiftAsDcMotor,rightWristAsServo

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  rightDriveAsDcMotor.setDirection("REVERSE");
  rightExtendAsDcMotor.setDirection("REVERSE");
  rightLiftAsDcMotor.setDirection("REVERSE");
  leftWristAsServo.setPosition(0.7);
  rightWristAsServo.setPosition(0.3);
  leftLiftAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightLiftAsDcMotor, "BRAKE");
  leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
  clawAsServo.setPosition(1);
  leftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
      leftDriveAsDcMotor.setDualMode("RUN_USING_ENCODER", rightDriveAsDcMotor, "RUN_USING_ENCODER");
      rightDriveAsDcMotor.setDualPower(0.75, leftDriveAsDcMotor, 0.75);
      leftDriveAsDcMotor.setDualTargetPosition(3750, rightDriveAsDcMotor, 3750);
      leftDriveAsDcMotor.setDualMode("RUN_TO_POSITION", rightDriveAsDcMotor, "RUN_TO_POSITION");
      linearOpMode.sleep(1250);
      leftDriveAsDcMotor.setDualPower(-1, rightDriveAsDcMotor, 0);
      linearOpMode.sleep(30000);
    }
  }
}
