// IDENTIFIERS_USED=clawAsServo,leftDriveAsDcMotor,leftWristAsServo,rightDriveAsDcMotor,rightExtendAsDcMotor,rightLiftAsDcMotor,rightWristAsServo

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  rightDriveAsDcMotor.setDirection("REVERSE");
  rightExtendAsDcMotor.setDirection("REVERSE");
  rightLiftAsDcMotor.setDirection("REVERSE");
  leftWristAsServo.setPosition(1);
  rightWristAsServo.setPosition(0);
  leftDriveAsDcMotor.setDualZeroPowerBehavior("BRAKE", rightDriveAsDcMotor, "BRAKE");
  clawAsServo.setPosition(0);
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    telemetry.update();
    leftDriveAsDcMotor.setDualPower(0.5, rightDriveAsDcMotor, 0.5);
    linearOpMode.sleep(100);
    leftDriveAsDcMotor.setDualPower(0, rightDriveAsDcMotor, 0);
    linearOpMode.sleep(500);
    leftDriveAsDcMotor.setDualPower(-0.5, rightDriveAsDcMotor, 0.5);
    linearOpMode.sleep(1750);
    leftDriveAsDcMotor.setDualPower(0, rightDriveAsDcMotor, 0);
    leftDriveAsDcMotor.setDualPower(0.5, rightDriveAsDcMotor, 0.5);
    linearOpMode.sleep(1000);
    leftDriveAsDcMotor.setDualPower(0, rightDriveAsDcMotor, 0);
    clawAsServo.setPosition(1);
    linearOpMode.sleep(750);
  }
}
