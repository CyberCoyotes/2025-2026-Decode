// IDENTIFIERS_USED=ClawAsServo,imuAsBNO055IMU,LeftDriveAsDcMotor,LiftAsDcMotor,RightDriveAsDcMotor

var i, targetOrientationAngl, target_position, targetorientationangle, Angles, recognition, Location, zOrientation, IMUparameters, recognitions, index;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  LiftAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  RightDriveAsDcMotor.setDirection("REVERSE");
  LiftAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  vuforiaCurrentGameAccess.initialize_withWebcam_2(navigationAccess.getWebcamName("Webcam 1"), '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  // Set isModelTensorFlow2 to true if you used a TensorFlow
  // 2 tool, such as ftc-ml, to create the model.
  //
  // Set isModelQuantized to true if the model is
  // quantized. Models created with ftc-ml are quantized.
  //
  // Set inputSize to the image size corresponding to the model.
  // If your model is based on SSD MobileNet v2
  // 320x320, the image size is 300 (srsly!).
  // If your model is based on SSD MobileNet V2 FPNLite 320x320, the image size is 320.
  // If your model is based on SSD MobileNet V1 FPN 640x640 or
  // SSD MobileNet V2 FPNLite 640x640, the image size is 640.
  tfodAccess.useModelFromFile('Custom22091.tflite', JSON.stringify(['1 Head', '2 Paw', '3 Krem']), true, true, 320);
  tfodAccess.initialize(vuforiaCurrentGameAccess, 0.8, true, true);
  tfodAccess.setClippingMargins(0, 80, 0, 0);
  tfodAccess.activate();
  tfodAccess.setZoom(2, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  IMUparameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setSensorMode(IMUparameters, "IMU");
  bno055imuParametersAccess.setAngleUnit(IMUparameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(IMUparameters, "METERS_PERSEC_PERSEC");
  telemetryAddTextData('status', 'init IMU...Please wait ');
  telemetry.update();
  imuAsBNO055IMU.initialize(IMUparameters);
  telemetryAddTextData('status', 'IMU initialized');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      // Get a list of recognitions from TFOD.
      recognitions = JSON.parse(tfodAccess.getRecognitions());
      // If list is empty, inform the user. Otherwise, go
      // through list and display info for each recognition.
      if (listLength(miscAccess, recognitions) == 0) {
        telemetryAddTextData('TFOD', 'No items detected.');
      } else {
        index = 0;
        // Iterate through list and call a function to
        // display info for each recognized object.
        for (var recognition_index in recognitions) {
          recognition = recognitions[recognition_index];
          displayInfo(index);
          index = index + 1;
        }
      }
      telemetry.update();
      if (Location == 1) {
        BoltAuto();
      } else if (Location == 2) {
        BulbAuto();
      } else if (Location == 3) {
        PanelAuto();
      } else {
        BoltAuto();
      }
    }
  }
  tfodAccess.deactivate();
}

function mathMean(myList) {
  return myList.reduce(function(x, y) {return x + y;}) / myList.length;
}

/**
 * Describe this function...
 */
function displayInfo(i) {
  // Display the location of the top left corner
  // of the detection boundary for the recognition
  telemetryAddTextData(['Label: ',startBlockExecution("TfodRecognition.Label") ? endBlockExecution(recognition.Label) : 0,', Confidence: ',startBlockExecution("TfodRecognition.Confidence") ? endBlockExecution(recognition.Confidence) : 0].join(''), ['X: ',Math.round(mathMean([miscAccess.roundDecimal(startBlockExecution("TfodRecognition.Left") ? endBlockExecution(recognition.Left) : 0, 0), miscAccess.roundDecimal(startBlockExecution("TfodRecognition.Right") ? endBlockExecution(recognition.Right) : 0, 0)])),', Y: ',Math.round(mathMean([miscAccess.roundDecimal(startBlockExecution("TfodRecognition.Top") ? endBlockExecution(recognition.Top) : 0, 0), miscAccess.roundDecimal(startBlockExecution("TfodRecognition.Bottom") ? endBlockExecution(recognition.Bottom) : 0, 0)]))].join(''));
  if ((startBlockExecution("TfodRecognition.Label") ? endBlockExecution(recognition.Label) : 0) == '1 Head') {
    telemetryAddTextData('Recognition:', '1 Head');
    Location = 1;
  } else if ((startBlockExecution("TfodRecognition.Label") ? endBlockExecution(recognition.Label) : 0) == '2 Paw') {
    telemetryAddTextData('Recognition:', '2 Paw');
    Location = 2;
  } else if ((startBlockExecution("TfodRecognition.Label") ? endBlockExecution(recognition.Label) : 0) == '3 Krem') {
    telemetryAddTextData('Recognition:', '3 Krem');
    Location = 3;
  } else {
    telemetryAddTextData('Recognition:', 'Unknown');
    Location = 1;
  }
}

/**
 * Describe this function...
 */
function getZAxisOrientation() {
  Angles = imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES");
  return orientationAccess.getFirstAngle(Angles);
}

/**
 * Describe this function...
 */
function Rotate_Cw(targetOrientationAngl) {
  zOrientation = getZAxisOrientation();
  LeftDriveAsDcMotor.setDualPower(0.2, RightDriveAsDcMotor, -0.2);
  while (zOrientation > targetOrientationAngl) {
    zOrientation = getZAxisOrientation();
  }
  LeftDriveAsDcMotor.setDualPower(0, RightDriveAsDcMotor, 0);
  linearOpMode.sleep(250);
}

/**
 * Describe this function...
 */
function move_to_position(target_position) {
  LeftDriveAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", RightDriveAsDcMotor, "STOP_AND_RESET_ENCODER");
  LeftDriveAsDcMotor.setDualMode("RUN_USING_ENCODER", RightDriveAsDcMotor, "RUN_USING_ENCODER");
  LeftDriveAsDcMotor.setDualPower(0.4, RightDriveAsDcMotor, 0.4);
  while (LeftDriveAsDcMotor.getCurrentPosition() < target_position) {
  }
  LeftDriveAsDcMotor.setDualPower(0, RightDriveAsDcMotor, 0);
  linearOpMode.sleep(250);
}

/**
 * Describe this function...
 */
function rotateCCW(targetorientationangle) {
  zOrientation = getZAxisOrientation();
  LeftDriveAsDcMotor.setDualPower(-0.2, RightDriveAsDcMotor, 0.2);
  while (zOrientation < targetorientationangle) {
    zOrientation = getZAxisOrientation();
  }
  LeftDriveAsDcMotor.setDualPower(0, RightDriveAsDcMotor, 0);
  linearOpMode.sleep(250);
}

/**
 * Describe this function...
 */
function BoltAuto() {
  ClawAsServo.setPosition(0);
  linearOpMode.sleep(1000);
  move_to_position(0.05 * 1440);
  linearOpMode.sleep(1000);
  rotateCCW(17.5);
  linearOpMode.sleep(1000);
  LiftAsDcMotor.setTargetPosition(2500);
  LiftAsDcMotor.setMode("RUN_TO_POSITION");
  LiftAsDcMotor.setPower(1);
  LeftDriveAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.sleep(2000);
  move_to_position(0.075 * 1440);
  linearOpMode.sleep(1000);
  ClawAsServo.setPosition(0.25);
  linearOpMode.sleep(500);
  RightDriveAsDcMotor.setDualPower(-0.3, LeftDriveAsDcMotor, -0.3);
  linearOpMode.sleep(500);
  RightDriveAsDcMotor.setDualPower(0, LeftDriveAsDcMotor, 0);
  ClawAsServo.setPosition(0);
  LiftAsDcMotor.setTargetPosition(0);
  LiftAsDcMotor.setMode("RUN_TO_POSITION");
  LiftAsDcMotor.setPower(1);
  LeftDriveAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.sleep(500);
  Rotate_Cw(15);
  linearOpMode.sleep(1000);
  move_to_position(0.35 * 1440);
  linearOpMode.sleep(1000);
  rotateCCW(65);
  linearOpMode.sleep(1000);
  move_to_position(0.2 * 1440);
  linearOpMode.sleep(20000);
}

/**
 * Describe this function...
 */
function BulbAuto() {
  ClawAsServo.setPosition(0);
  linearOpMode.sleep(1000);
  move_to_position(0.05 * 1440);
  linearOpMode.sleep(1000);
  rotateCCW(17.5);
  linearOpMode.sleep(1000);
  LiftAsDcMotor.setTargetPosition(2500);
  LiftAsDcMotor.setMode("RUN_TO_POSITION");
  LiftAsDcMotor.setPower(1);
  LeftDriveAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.sleep(2000);
  move_to_position(0.075 * 1440);
  linearOpMode.sleep(1000);
  ClawAsServo.setPosition(0.25);
  linearOpMode.sleep(500);
  RightDriveAsDcMotor.setDualPower(-0.3, LeftDriveAsDcMotor, -0.3);
  linearOpMode.sleep(500);
  RightDriveAsDcMotor.setDualPower(0, LeftDriveAsDcMotor, 0);
  ClawAsServo.setPosition(0);
  LiftAsDcMotor.setTargetPosition(0);
  LiftAsDcMotor.setMode("RUN_TO_POSITION");
  LiftAsDcMotor.setPower(1);
  LeftDriveAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.sleep(500);
  Rotate_Cw(15);
  linearOpMode.sleep(1000);
  move_to_position(0.35 * 1440);
  linearOpMode.sleep(20000);
}

/**
 * Describe this function...
 */
function PanelAuto() {
  ClawAsServo.setPosition(0);
  linearOpMode.sleep(1000);
  move_to_position(0.05 * 1440);
  linearOpMode.sleep(1000);
  rotateCCW(17.5);
  linearOpMode.sleep(1000);
  LiftAsDcMotor.setTargetPosition(2500);
  LiftAsDcMotor.setMode("RUN_TO_POSITION");
  LiftAsDcMotor.setPower(1);
  LeftDriveAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.sleep(2000);
  move_to_position(0.075 * 1440);
  linearOpMode.sleep(1000);
  ClawAsServo.setPosition(0.25);
  linearOpMode.sleep(500);
  RightDriveAsDcMotor.setDualPower(-0.3, LeftDriveAsDcMotor, -0.3);
  linearOpMode.sleep(500);
  RightDriveAsDcMotor.setDualPower(0, LeftDriveAsDcMotor, 0);
  ClawAsServo.setPosition(0);
  LiftAsDcMotor.setTargetPosition(0);
  LiftAsDcMotor.setMode("RUN_TO_POSITION");
  LiftAsDcMotor.setPower(1);
  LeftDriveAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.sleep(500);
  Rotate_Cw(15);
  linearOpMode.sleep(1000);
  move_to_position(0.35 * 1440);
  linearOpMode.sleep(1000);
  Rotate_Cw(-60);
  linearOpMode.sleep(500);
  move_to_position(0.33 * 1440);
  linearOpMode.sleep(20000);
}
